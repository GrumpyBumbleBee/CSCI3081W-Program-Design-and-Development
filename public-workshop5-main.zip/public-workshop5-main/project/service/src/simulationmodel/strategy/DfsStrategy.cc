#include "DfsStrategy.h"

#include "DepthFirstSearch.h"

DfsStrategy::DfsStrategy(Vector3 pos, Vector3 des, const routing::Graph* g) {
  if (g) {
    path = g->getPath(pos, des, routing::DepthFirstSearch()).value();
    path.push_back(des);
  } else {
    path = {pos, des};
  }
}
