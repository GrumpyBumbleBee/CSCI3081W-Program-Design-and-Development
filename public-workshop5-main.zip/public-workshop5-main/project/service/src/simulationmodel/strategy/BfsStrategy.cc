#include "BfsStrategy.h"

#include "BreadthFirstSearch.h"

BfsStrategy::BfsStrategy(Vector3 pos, Vector3 des, const routing::Graph* g) {
  if (g) {
    path = g->getPath(pos, des, routing::BreadthFirstSearch()).value();
    path.push_back(des);
  } else {
    path = {pos, des};
  }
}
